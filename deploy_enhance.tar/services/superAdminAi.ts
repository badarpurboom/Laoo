
import { GoogleGenAI } from "@google/genai";
import OpenAI from "openai";
import { MenuItem, Restaurant } from "../types";

export type AIAction =
    | { type: 'RESPONSE'; message: string }
    | { type: 'FETCH_MENU'; restaurantId: string; restaurantName: string; reason: string }
    | { type: 'CONFIRM_DELETE'; itemId: string; itemName: string; restaurantId: string }
    | { type: 'CONFIRM_UPDATE_PRICE'; itemId: string; itemName: string; newPrice: number; restaurantId: string };

export const processSuperAdminQuery = async (
    query: string,
    restaurants: Restaurant[],
    apiKey: string,
    provider: 'gemini' | 'openai',
    context?: { menuItems?: MenuItem[]; restaurantName?: string },
    globalStats?: { totalRestaurants: number; activeRestaurants: number; totalOrders: number; totalRevenue: number }
): Promise<AIAction> => {

    if (!apiKey) return { type: 'RESPONSE', message: "API Key missing. Please configure it in settings." };

    // 1. Context Building
    let prompt = "";

    if (!context?.menuItems) {
        // Broad Context: List of Restaurants
        const resSummary = restaurants.map(r => ({
            id: r.id,
            name: r.name,
            status: r.isActive ? 'Active' : 'Inactive',
            itemCount: (r as any)._count?.menuItems || 0,
            orderCount: (r as any)._count?.orders || 0,
            trialEnds: (r as any).trialEndDate ? new Date((r as any).trialEndDate).toISOString().split('T')[0] : 'N/A'
        }));

        prompt = `
        You are the "Master AI" for a Restaurant SaaS Platform. You have Super Admin privileges.
        
        Global Business Stats:
        ${globalStats ? JSON.stringify(globalStats) : 'Not available'}

        Current System State (Restaurants):
        ${JSON.stringify(resSummary)}
        
        User Query: "${query}"
        
        Instructions:
        1. If the user asks for GENERAL stats (count, active, revenue, expiry, etc.), answer directly using the data above.
        2. If the user wants to DELETE or MODIFY a menu item / price for a specific restaurant, you need to see their menu first.
           - Identify the restaurant name from the query.
           - Find the matching ID from the list.
           - Return a JSON object: { "type": "FETCH_MENU", "restaurantId": "...", "restaurantName": "...", "reason": "To find the item..." }
        3. If you can't find the restaurant, ask for clarification.
        4. Do NOT hallucinate.
        
        Output Format:
        - If answering: Just the text answer.
        - If needing menu: ONLY the JSON object.
        `;
    } else {
        // Specific Context: Menu is loaded
        prompt = `
        You are the "Master AI". You are processing a request for restaurant: "${context.restaurantName}".
        
        User Query: "${query}"
        
        Loaded Menu Items for ${context.restaurantName}:
        ${JSON.stringify(context.menuItems.map(m => ({ id: m.id, name: m.name, price: m.fullPrice })))}
        
        Instructions:
        1. Identify the item the user wants to modify/delete.
        2. If DELETE: Return JSON { "type": "CONFIRM_DELETE", "itemId": "...", "itemName": "...", "restaurantId": "..." }
        3. If UPDATE PRICE: Return JSON { "type": "CONFIRM_UPDATE_PRICE", "itemId": "...", "itemName": "...", "newPrice": 123, "restaurantId": "..." }
        4. If item not found, apologize and list similar items if any.
        
        Output Format:
        - JSON Object for actions.
        - Text for errors/questions.
        `;
    }

    try {
        let responseText = "";

        if (provider === 'openai') {
            const openai = new OpenAI({ apiKey, dangerouslyAllowBrowser: true });
            const completion = await openai.chat.completions.create({
                messages: [{ role: "system", content: prompt }],
                model: "gpt-4o",
            });
            responseText = completion.choices[0].message.content || "";
        } else {
            const ai = new GoogleGenAI({ apiKey });
            const response = await ai.models.generateContent({
                model: 'gemini-2.0-flash',
                contents: prompt,
                config: { temperature: 0.1 }
            });
            responseText = response.text || "";
        }

        // Clean cleanup
        const cleanText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();

        try {
            // Try parsing as JSON action
            if (cleanText.startsWith('{')) {
                const action = JSON.parse(cleanText);
                if (action.type) return action; // It's a valid action
            }
        } catch (e) {
            // Not JSON, treat as text
        }

        return { type: 'RESPONSE', message: responseText };

    } catch (error: any) {
        console.error("AI Error:", error);
        return { type: 'RESPONSE', message: `AI Error: ${error.message}` };
    }
};
