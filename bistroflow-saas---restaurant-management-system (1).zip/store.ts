
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { 
  MenuItem, 
  Category, 
  Order, 
  RestaurantSettings, 
  AIConfig, 
  PaymentConfig,
  OrderStatus,
  OrderType
} from './types';

interface AppState {
  // Menu
  categories: Category[];
  menuItems: MenuItem[];
  
  // Orders
  orders: Order[];
  
  // Configs
  settings: RestaurantSettings;
  aiConfig: AIConfig;
  paymentConfig: PaymentConfig;
  
  // Auth
  isAuthenticated: boolean;
  
  // Actions
  login: (password: string) => boolean;
  logout: () => void;
  addOrder: (order: Order) => void;
  updateOrderStatus: (id: string, status: OrderStatus) => void;
  updateMenuItem: (item: MenuItem) => void;
  addMenuItem: (item: MenuItem) => void;
  deleteMenuItem: (id: string) => void;
  addCategory: (name: string) => void;
  updateSettings: (settings: RestaurantSettings) => void;
  updateAIConfig: (config: AIConfig) => void;
  updatePaymentConfig: (config: PaymentConfig) => void;
}

// Initial Data
const initialCategories: Category[] = [
  { id: '1', name: 'Starters' },
  { id: '2', name: 'Main Course' },
  { id: '3', name: 'Beverages' },
  { id: '4', name: 'Desserts' },
];

const initialMenuItems: MenuItem[] = [
  { id: 'm1', name: 'Crispy Corn', description: 'Sweet corn fried with herbs', price: 12.99, categoryId: '1', imageUrl: 'https://picsum.photos/400/300?random=1', isVeg: true, isAvailable: true },
  { id: 'm2', name: 'Chicken Wings', description: 'Spicy BBQ wings', price: 15.50, categoryId: '1', imageUrl: 'https://picsum.photos/400/300?random=2', isVeg: false, isAvailable: true },
  { id: 'm3', name: 'Paneer Butter Masala', description: 'Cottage cheese in rich gravy', price: 18.00, categoryId: '2', imageUrl: 'https://picsum.photos/400/300?random=3', isVeg: true, isAvailable: true },
  { id: 'm4', name: 'Butter Chicken', description: 'Classic creamy chicken curry', price: 19.50, categoryId: '2', imageUrl: 'https://picsum.photos/400/300?random=4', isVeg: false, isAvailable: true },
  { id: 'm5', name: 'Iced Tea', description: 'Refreshing peach tea', price: 4.99, categoryId: '3', imageUrl: 'https://picsum.photos/400/300?random=5', isVeg: true, isAvailable: true },
  { id: 'm6', name: 'Gulab Jamun', description: 'Fried dough balls in syrup', price: 6.50, categoryId: '4', imageUrl: 'https://picsum.photos/400/300?random=6', isVeg: true, isAvailable: true },
];

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      categories: initialCategories,
      menuItems: initialMenuItems,
      orders: [],
      isAuthenticated: false,
      settings: {
        name: "BistroFlow Central",
        logoUrl: "https://picsum.photos/100/100?random=logo",
        address: "123 Food Street, Tech City, CA 94103",
        contact: "+1 (555) 000-1111",
        gstNumber: "22AAAAA0000A1Z5",
        taxPercentage: 5,
        deliveryCharges: 2.50,
        isOpen: true
      },
      aiConfig: {
        provider: 'gemini',
        apiKey: '',
        model: 'gemini-3-flash-preview',
        temperature: 0.7,
        promptSystem: 'You are a professional business analyst for a restaurant. You have access to order and menu data. Format your answers concisely.'
      },
      paymentConfig: {
        stripeEnabled: true,
        stripeApiKey: 'pk_test_mock',
        razorpayEnabled: false,
        razorpayApiKey: ''
      },

      login: (password: string) => {
        if (password === 'admin123') {
          set({ isAuthenticated: true });
          return true;
        }
        return false;
      },
      logout: () => set({ isAuthenticated: false }),
      addOrder: (order) => set((state) => ({ orders: [order, ...state.orders] })),
      updateOrderStatus: (id, status) => set((state) => ({
        orders: state.orders.map(o => o.id === id ? { ...o, status } : o)
      })),
      updateMenuItem: (item) => set((state) => ({
        menuItems: state.menuItems.map(m => m.id === item.id ? item : m)
      })),
      addMenuItem: (item) => set((state) => ({
        menuItems: [...state.menuItems, item]
      })),
      deleteMenuItem: (id) => set((state) => ({
        menuItems: state.menuItems.filter(m => m.id !== id)
      })),
      addCategory: (name) => set((state) => ({
        categories: [...state.categories, { id: Math.random().toString(36).substr(2, 9), name }]
      })),
      updateSettings: (settings) => set({ settings }),
      updateAIConfig: (aiConfig) => set({ aiConfig }),
      updatePaymentConfig: (paymentConfig) => set({ paymentConfig }),
    }),
    {
      name: 'bistroflow-storage',
    }
  )
);
