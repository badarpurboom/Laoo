
export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'completed' | 'cancelled';
export type OrderType = 'dine-in' | 'takeaway' | 'delivery';

export interface Category {
  id: string;
  name: string;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  categoryId: string;
  imageUrl: string;
  isVeg: boolean;
  isAvailable: boolean;
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export interface Order {
  id: string;
  customerName: string;
  items: CartItem[];
  totalAmount: number;
  status: OrderStatus;
  orderType: OrderType;
  createdAt: string;
  tableNumber?: string;
  address?: string;
  paymentStatus: 'pending' | 'paid' | 'failed';
}

export interface RestaurantSettings {
  name: string;
  logoUrl: string;
  address: string;
  contact: string;
  gstNumber: string;
  taxPercentage: number;
  deliveryCharges: number;
  isOpen: boolean;
}

export interface AIConfig {
  provider: 'openai' | 'gemini';
  apiKey: string;
  model: string;
  temperature: number;
  promptSystem: string;
}

export interface PaymentConfig {
  stripeEnabled: boolean;
  stripeApiKey: string;
  razorpayEnabled: boolean;
  razorpayApiKey: string;
}
