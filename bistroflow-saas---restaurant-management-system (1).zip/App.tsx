
import React, { useState } from 'react';
import { useStore } from './store';
import CustomerView from './components/customer/CustomerView';
import AdminView from './components/admin/AdminView';
import DocumentationView from './components/DocumentationView';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<'customer' | 'admin' | 'docs'>('customer');
  const { isAuthenticated } = useStore();

  return (
    <div className="min-h-screen bg-slate-50">
      {/* View Switcher Overlay (For Demo Purposes) */}
      <div className="fixed bottom-4 left-4 z-50 flex gap-2 p-2 bg-white/80 backdrop-blur rounded-full shadow-lg border border-slate-200">
        <button 
          onClick={() => setActiveView('customer')}
          className={`px-4 py-2 rounded-full text-xs font-semibold transition-all ${activeView === 'customer' ? 'bg-orange-500 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'}`}
        >
          <i className="fas fa-utensils mr-2"></i> Customer View
        </button>
        <button 
          onClick={() => setActiveView('admin')}
          className={`px-4 py-2 rounded-full text-xs font-semibold transition-all ${activeView === 'admin' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'}`}
        >
          <i className="fas fa-user-shield mr-2"></i> Admin Panel
        </button>
        <button 
          onClick={() => setActiveView('docs')}
          className={`px-4 py-2 rounded-full text-xs font-semibold transition-all ${activeView === 'docs' ? 'bg-slate-800 text-white shadow-md' : 'text-slate-600 hover:bg-slate-100'}`}
        >
          <i className="fas fa-book mr-2"></i> System Architecture
        </button>
      </div>

      {activeView === 'customer' && <CustomerView />}
      {activeView === 'admin' && <AdminView />}
      {activeView === 'docs' && <DocumentationView />}
    </div>
  );
};

export default App;
