
import React, { useState, useMemo } from 'react';
import { useStore } from '../../store';
import { MenuItem, CartItem, Order, OrderType } from '../../types';

const CustomerView: React.FC = () => {
  const { menuItems, categories, settings, addOrder } = useStore();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showCart, setShowCart] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'details' | 'success'>('cart');
  const [orderType, setOrderType] = useState<OrderType>('dine-in');
  const [customerName, setCustomerName] = useState('');
  const [tableOrAddress, setTableOrAddress] = useState('');

  const filteredMenu = useMemo(() => {
    if (selectedCategory === 'all') return menuItems;
    return menuItems.filter(item => item.categoryId === selectedCategory);
  }, [menuItems, selectedCategory]);

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const taxAmount = (cartTotal * settings.taxPercentage) / 100;
  const deliveryFee = orderType === 'delivery' ? settings.deliveryCharges : 0;
  const finalTotal = cartTotal + taxAmount + deliveryFee;

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  };

  const handleCheckout = () => {
    if (!customerName || (orderType !== 'takeaway' && !tableOrAddress)) {
      alert("Please fill in all details");
      return;
    }

    const newOrder: Order = {
      id: `ORD-${Date.now()}`,
      customerName,
      items: cart,
      totalAmount: finalTotal,
      status: 'pending',
      orderType,
      createdAt: new Date().toISOString(),
      tableNumber: orderType === 'dine-in' ? tableOrAddress : undefined,
      address: orderType === 'delivery' ? tableOrAddress : undefined,
      paymentStatus: 'pending'
    };

    addOrder(newOrder);
    setCheckoutStep('success');
  };

  return (
    <div className="pb-20">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white shadow-sm px-4 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <img src={settings.logoUrl} alt="logo" className="w-10 h-10 rounded-lg" />
          <h1 className="text-xl font-bold tracking-tight text-slate-800">{settings.name}</h1>
        </div>
        <button 
          onClick={() => setShowCart(true)}
          className="relative p-2 text-slate-600 hover:text-orange-500 transition-colors"
        >
          <i className="fas fa-shopping-basket text-2xl"></i>
          {cart.length > 0 && (
            <span className="absolute -top-1 -right-1 bg-orange-500 text-white text-[10px] font-bold w-5 h-5 flex items-center justify-center rounded-full animate-pulse">
              {cart.reduce((s, i) => s + i.quantity, 0)}
            </span>
          )}
        </button>
      </header>

      {/* Hero */}
      <section className="px-4 py-8 bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-b-[2.5rem] mb-8">
        <h2 className="text-3xl font-bold mb-2">Delicious Food,</h2>
        <p className="text-orange-100 text-lg">Delivered straight to your table.</p>
      </section>

      {/* Category Filter */}
      <div className="flex gap-3 overflow-x-auto px-4 pb-4 no-scrollbar">
        <button 
          onClick={() => setSelectedCategory('all')}
          className={`whitespace-nowrap px-6 py-2 rounded-full text-sm font-medium transition-all ${selectedCategory === 'all' ? 'bg-slate-800 text-white' : 'bg-white text-slate-600 border border-slate-200'}`}
        >
          All Items
        </button>
        {categories.map(cat => (
          <button 
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`whitespace-nowrap px-6 py-2 rounded-full text-sm font-medium transition-all ${selectedCategory === cat.id ? 'bg-slate-800 text-white' : 'bg-white text-slate-600 border border-slate-200'}`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {/* Menu Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-4 mt-4">
        {filteredMenu.map(item => (
          <div key={item.id} className="bg-white rounded-2xl p-3 shadow-sm border border-slate-100 flex gap-4">
            <img src={item.imageUrl} alt={item.name} className="w-24 h-24 rounded-xl object-cover" />
            <div className="flex-1 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-slate-800">{item.name}</h3>
                  <span className={`text-[10px] px-2 py-0.5 rounded ${item.isVeg ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {item.isVeg ? 'VEG' : 'NON-VEG'}
                  </span>
                </div>
                <p className="text-xs text-slate-500 line-clamp-2 mt-1">{item.description}</p>
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="font-bold text-orange-600">${item.price.toFixed(2)}</span>
                <button 
                  disabled={!item.isAvailable}
                  onClick={() => addToCart(item)}
                  className="bg-orange-500 text-white w-8 h-8 rounded-full flex items-center justify-center hover:bg-orange-600 disabled:bg-slate-300 shadow-sm transition-transform active:scale-95"
                >
                  <i className="fas fa-plus text-xs"></i>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Cart Modal */}
      {showCart && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center">
          <div className="bg-white w-full sm:max-w-md h-[90vh] sm:h-auto sm:max-h-[80vh] rounded-t-3xl sm:rounded-3xl overflow-hidden flex flex-col">
            <div className="p-6 border-b flex justify-between items-center">
              <h2 className="text-xl font-bold text-slate-800">Your Cart</h2>
              <button onClick={() => { setShowCart(false); setCheckoutStep('cart'); }} className="text-slate-400 hover:text-slate-600">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
              {checkoutStep === 'cart' && (
                <>
                  {cart.length === 0 ? (
                    <div className="text-center py-20">
                      <i className="fas fa-shopping-cart text-slate-200 text-6xl mb-4"></i>
                      <p className="text-slate-400">Your cart is empty</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {cart.map(item => (
                        <div key={item.id} className="flex justify-between items-center bg-slate-50 p-3 rounded-xl">
                          <div className="flex items-center gap-3">
                            <img src={item.imageUrl} className="w-12 h-12 rounded-lg object-cover" />
                            <div>
                              <h4 className="text-sm font-semibold">{item.name}</h4>
                              <p className="text-xs text-slate-500">${item.price.toFixed(2)}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="text-sm font-bold text-slate-700">x{item.quantity}</span>
                            <button onClick={() => removeFromCart(item.id)} className="text-red-400 hover:text-red-600">
                              <i className="fas fa-trash-alt"></i>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}

              {checkoutStep === 'details' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Order Type</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['dine-in', 'takeaway', 'delivery'].map((type) => (
                        <button
                          key={type}
                          onClick={() => setOrderType(type as OrderType)}
                          className={`py-2 px-1 rounded-lg text-xs font-semibold capitalize border transition-all ${orderType === type ? 'bg-slate-800 text-white border-slate-800' : 'bg-white text-slate-600 border-slate-200'}`}
                        >
                          {type.replace('-', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Customer Name</label>
                    <input 
                      type="text" 
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Your name"
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                    />
                  </div>
                  {orderType !== 'takeaway' && (
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-1">
                        {orderType === 'dine-in' ? 'Table Number' : 'Delivery Address'}
                      </label>
                      <input 
                        type="text" 
                        value={tableOrAddress}
                        onChange={(e) => setTableOrAddress(e.target.value)}
                        placeholder={orderType === 'dine-in' ? "e.g. Table 5" : "Full address"}
                        className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none"
                      />
                    </div>
                  )}
                </div>
              )}

              {checkoutStep === 'success' && (
                <div className="text-center py-10">
                  <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i className="fas fa-check text-4xl"></i>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-800 mb-2">Order Confirmed!</h3>
                  <p className="text-slate-500 mb-6">Your order is being prepared. Enjoy your meal!</p>
                  <button 
                    onClick={() => { setShowCart(false); setCheckoutStep('cart'); setCart([]); }}
                    className="w-full py-3 bg-slate-800 text-white rounded-xl font-bold hover:bg-slate-900"
                  >
                    Done
                  </button>
                </div>
              )}
            </div>

            {checkoutStep !== 'success' && cart.length > 0 && (
              <div className="p-6 border-t bg-slate-50">
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-slate-600 text-sm">
                    <span>Subtotal</span>
                    <span>${cartTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 text-sm">
                    <span>Tax ({settings.taxPercentage}%)</span>
                    <span>${taxAmount.toFixed(2)}</span>
                  </div>
                  {deliveryFee > 0 && (
                    <div className="flex justify-between text-slate-600 text-sm">
                      <span>Delivery Fee</span>
                      <span>${deliveryFee.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold text-slate-800">
                    <span>Total</span>
                    <span>${finalTotal.toFixed(2)}</span>
                  </div>
                </div>
                {checkoutStep === 'cart' ? (
                  <button 
                    onClick={() => setCheckoutStep('details')}
                    className="w-full py-4 bg-orange-500 text-white rounded-xl font-bold shadow-lg shadow-orange-200 hover:bg-orange-600 transition-colors"
                  >
                    Checkout
                  </button>
                ) : (
                  <button 
                    onClick={handleCheckout}
                    className="w-full py-4 bg-slate-800 text-white rounded-xl font-bold shadow-lg shadow-slate-200 hover:bg-slate-900 transition-colors"
                  >
                    Place Order
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CustomerView;
