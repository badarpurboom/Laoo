
import React, { useState } from 'react';
import { useStore } from '../../store';
import { MenuItem } from '../../types';

const MenuManager: React.FC = () => {
  const { menuItems, categories, addMenuItem, updateMenuItem, deleteMenuItem } = useStore();
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);

  const emptyItem: MenuItem = {
    id: '',
    name: '',
    description: '',
    price: 0,
    categoryId: categories[0]?.id || '',
    imageUrl: 'https://picsum.photos/400/300?random=' + Date.now(),
    isVeg: true,
    isAvailable: true
  };

  const [formData, setFormData] = useState<MenuItem>(emptyItem);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingItem) {
      updateMenuItem(formData);
    } else {
      addMenuItem({ ...formData, id: 'm' + Date.now() });
    }
    setShowModal(false);
    setEditingItem(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-slate-100">
        <div className="flex items-center gap-4">
          <div className="relative">
             <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs"></i>
             <input type="text" placeholder="Search menu..." className="pl-10 pr-4 py-2 bg-slate-100 border-none rounded-lg text-sm focus:ring-2 focus:ring-indigo-500 outline-none w-64" />
          </div>
          <select className="bg-slate-100 border-none rounded-lg text-sm px-4 py-2 outline-none">
            <option>All Categories</option>
            {categories.map(c => <option key={c.id}>{c.name}</option>)}
          </select>
        </div>
        <button 
          onClick={() => { setFormData(emptyItem); setEditingItem(null); setShowModal(true); }}
          className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-indigo-700 transition-colors shadow-lg shadow-indigo-100"
        >
          <i className="fas fa-plus mr-2"></i> Add Item
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {menuItems.map(item => (
          <div key={item.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden group">
            <div className="h-40 relative">
              <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                <button 
                  onClick={() => { setEditingItem(item); setFormData(item); setShowModal(true); }}
                  className="w-10 h-10 bg-white text-indigo-600 rounded-lg flex items-center justify-center hover:bg-indigo-50"
                >
                  <i className="fas fa-edit"></i>
                </button>
                <button 
                  onClick={() => deleteMenuItem(item.id)}
                  className="w-10 h-10 bg-white text-red-600 rounded-lg flex items-center justify-center hover:bg-red-50"
                >
                  <i className="fas fa-trash"></i>
                </button>
              </div>
              <div className="absolute top-2 right-2 flex gap-1">
                <span className={`px-2 py-0.5 rounded text-[8px] font-bold ${item.isAvailable ? 'bg-green-500 text-white' : 'bg-slate-500 text-white'}`}>
                  {item.isAvailable ? 'IN STOCK' : 'OUT OF STOCK'}
                </span>
              </div>
            </div>
            <div className="p-4">
              <div className="flex justify-between items-start mb-1">
                <h4 className="font-bold text-slate-800 text-sm">{item.name}</h4>
                <span className="text-indigo-600 font-bold text-sm">${item.price.toFixed(2)}</span>
              </div>
              <p className="text-xs text-slate-500 line-clamp-2">{item.description}</p>
              <div className="mt-3 pt-3 border-t flex justify-between items-center">
                 <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                   {categories.find(c => c.id === item.categoryId)?.name || 'Category'}
                 </span>
                 <span className={`w-2 h-2 rounded-full ${item.isVeg ? 'bg-green-500' : 'bg-red-500'}`}></span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden">
            <div className="p-6 border-b flex justify-between items-center bg-slate-50">
              <h3 className="text-xl font-bold text-slate-800">{editingItem ? 'Edit Menu Item' : 'New Menu Item'}</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <i className="fas fa-times text-xl"></i>
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Item Name</label>
                  <input 
                    required
                    type="text" 
                    value={formData.name}
                    onChange={e => setFormData({...formData, name: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" 
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Price ($)</label>
                  <input 
                    required
                    type="number" 
                    step="0.01"
                    value={formData.price}
                    onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" 
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Category</label>
                  <select 
                    value={formData.categoryId}
                    onChange={e => setFormData({...formData, categoryId: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                  </select>
                </div>
                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Description</label>
                  <textarea 
                    value={formData.description}
                    onChange={e => setFormData({...formData, description: e.target.value})}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none h-20"
                  ></textarea>
                </div>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={formData.isVeg}
                      onChange={e => setFormData({...formData, isVeg: e.target.checked})}
                      className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500" 
                    />
                    <span className="text-sm font-medium text-slate-700">Veg</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={formData.isAvailable}
                      onChange={e => setFormData({...formData, isAvailable: e.target.checked})}
                      className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500" 
                    />
                    <span className="text-sm font-medium text-slate-700">Available</span>
                  </label>
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-3 border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50">Cancel</button>
                <button type="submit" className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100">
                  {editingItem ? 'Save Changes' : 'Create Item'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default MenuManager;
