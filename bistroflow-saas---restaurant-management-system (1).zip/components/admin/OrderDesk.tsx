
import React from 'react';
import { useStore } from '../../store';
import { OrderStatus } from '../../types';

const OrderDesk: React.FC = () => {
  const { orders, updateOrderStatus } = useStore();

  const getStatusColor = (status: OrderStatus) => {
    switch(status) {
      case 'pending': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'preparing': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'ready': return 'bg-indigo-100 text-indigo-700 border-indigo-200';
      case 'completed': return 'bg-green-100 text-green-700 border-green-200';
      case 'cancelled': return 'bg-red-100 text-red-700 border-red-200';
      default: return 'bg-slate-100 text-slate-700';
    }
  };

  const statusFlow: OrderStatus[] = ['pending', 'preparing', 'ready', 'completed'];

  return (
    <div className="space-y-6">
      <div className="flex gap-4 overflow-x-auto pb-4 no-scrollbar">
        {statusFlow.concat(['cancelled']).map(status => (
          <div key={status} className="min-w-[150px] bg-white p-4 rounded-xl shadow-sm border border-slate-100">
            <p className="text-xs font-bold text-slate-400 uppercase mb-1">{status}</p>
            <p className="text-2xl font-bold text-slate-800">{orders.filter(o => o.status === status).length}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {orders.map(order => (
          <div key={order.id} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden flex flex-col">
            <div className={`p-4 border-b flex justify-between items-center ${getStatusColor(order.status)}`}>
              <div>
                <h4 className="font-bold">{order.id}</h4>
                <p className="text-[10px] font-medium opacity-70 capitalize">{order.orderType} • {order.tableNumber || order.address || 'Takeaway'}</p>
              </div>
              <span className="text-[10px] font-bold bg-white/50 px-2 py-1 rounded">{new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
            
            <div className="flex-1 p-4 space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-bold text-slate-800">{order.customerName}</span>
                <span className="text-xs text-slate-500">{order.items.reduce((s, i) => s + i.quantity, 0)} items</span>
              </div>
              
              <div className="space-y-1">
                {order.items.map((item, idx) => (
                  <div key={idx} className="flex justify-between text-xs text-slate-600">
                    <span>{item.quantity}x {item.name}</span>
                    <span>${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              
              <div className="pt-2 border-t border-dashed flex justify-between font-bold text-slate-800">
                <span>Total</span>
                <span>${order.totalAmount.toFixed(2)}</span>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t flex gap-2">
              {order.status !== 'completed' && order.status !== 'cancelled' && (
                <>
                  <button 
                    onClick={() => {
                      const currentIndex = statusFlow.indexOf(order.status);
                      if (currentIndex < statusFlow.length - 1) {
                        updateOrderStatus(order.id, statusFlow[currentIndex + 1]);
                      }
                    }}
                    className="flex-1 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 transition-colors"
                  >
                    Move to {statusFlow[statusFlow.indexOf(order.status) + 1] || 'Done'}
                  </button>
                  <button 
                    onClick={() => updateOrderStatus(order.id, 'cancelled')}
                    className="px-4 py-2 border border-red-200 text-red-500 rounded-lg text-xs font-bold hover:bg-red-50 transition-colors"
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </>
              )}
              {order.status === 'completed' && (
                <div className="w-full text-center py-2 text-green-600 font-bold text-xs">
                  <i className="fas fa-check-circle mr-2"></i> Order Completed
                </div>
              )}
              {order.status === 'cancelled' && (
                <div className="w-full text-center py-2 text-red-600 font-bold text-xs">
                   Cancelled
                </div>
              )}
            </div>
          </div>
        ))}

        {orders.length === 0 && (
          <div className="col-span-full py-20 text-center">
            <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-300">
              <i className="fas fa-receipt text-3xl"></i>
            </div>
            <h3 className="text-slate-500 font-medium">No active orders</h3>
            <p className="text-sm text-slate-400">Orders placed by customers will appear here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrderDesk;
